package com.cg.plp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.plp.bean.BookBean;
import com.cg.plp.bean.BookRegistrationBean;
import com.cg.plp.bean.UserBean;
import com.cg.plp.exception.LibraryException;
import com.cg.plp.exception.StudentException;
import com.cg.plp.util.DBConnection;

public class LMSDaoImpl implements ILMSDao
{
	/*******************************************************************************************************
	 - Function Name	:	addDetails()
	 - Input Parameters	:	userBean
	 - Return Type		:	String
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To Register the user
	 ********************************************************************************************************/ 
	@Override
	public String addDetails(UserBean userBean) throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String userId=null;
			try
			{
				preparedStatement = connection.prepareStatement(IQueryMapper.getUserId);
				resultSet=preparedStatement.executeQuery();
				resultSet.next();
				userId=resultSet.getString(1);
				preparedStatement.close();
				System.out.println(userId);
				
				
				preparedStatement=connection.prepareStatement(IQueryMapper.insertDetails);
				preparedStatement.setString(1,userId);
				preparedStatement.setString(2,userBean.getName());
				preparedStatement.setString(3,userBean.getPassword());
				preparedStatement.setString(4,userBean.getEmailId());
				preparedStatement.setString(5,userBean.getLibrarian());
				preparedStatement.executeUpdate();
				//connection.commit();
				preparedStatement.close();
			}
			catch(SQLException sqlException)
			{
				throw new LibraryException("error in registering the user");
			}

			finally
			{
				try 
				{
					preparedStatement.close();
					connection.close();
					resultSet.close();
				}
				catch (SQLException sqlException) 
				{
					throw new LibraryException("Error in closing database connection in registration page");
				}
			}
		return userId;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	isUserValid()
	 - Input Parameters	:	userId, password
	 - Return Type		:	int
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To validate the user
	 ********************************************************************************************************/ 
	
	@Override
	public int isUserValid(String userId, String password) throws LibraryException
	{			
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		int status=0;
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.getPassword);
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				String pass=resultSet.getString("password");
				if(pass.equals(password))
				{
					preparedStatement=connection.prepareStatement(IQueryMapper.checkUser);
					preparedStatement.setString(1,userId);
					resultSet=preparedStatement.executeQuery();
					resultSet.next();
					String lib=resultSet.getString(1);
					preparedStatement.close();
					if(lib.equals("true"))
						status=1;
					else
						status=2;
				}
				else
				{
					//System.out.println("Incorrect password.Please enter a valid password");
					status=3;
				}
			}
			else
			{
				//System.out.println("Incorrect userid.Please enter a valid userid");
				status=4;
			}
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration page");
			}
		}
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	getUserName()
	 - Input Parameters	:	userId
	 - Return Type		:	String
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To get the user name for the user id
	 ********************************************************************************************************/ 
	
	@Override
	public String getUserName(String userId) throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String userName=null;
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.getUserName);
			preparedStatement.setString(1,userId);
			
			resultSet=preparedStatement.executeQuery();
			resultSet.next();
			userName=resultSet.getString(1);
			//System.out.println("1111"+userName);
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in registration page");
			}
		}
		return userName;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addBooks()
	 - Input Parameters	:	bookBean
	 - Return Type		:	boolean
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To add the new books to the inventory
	 ********************************************************************************************************/ 
	
	@Override
	public boolean addBooks(BookBean bookBean) throws LibraryException 
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		
		boolean status=false;
		
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.insertBook);
			preparedStatement.setString(1,bookBean.getBookId());
			preparedStatement.setString(2,bookBean.getBookName());
			preparedStatement.setString(3,bookBean.getAuthor1());
			preparedStatement.setString(4,bookBean.getAuthor2());
			preparedStatement.setString(5,bookBean.getPublisher());
			preparedStatement.setString(6,bookBean.getYearOfPublication());
			preparedStatement.setInt(7,bookBean.getNoOfCopies());
			preparedStatement.executeUpdate();
			status=true;
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Given Book id already exists in database");
		}
		
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	showBooks()
	 - Return Type		:	ArrayList<BookBean>
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To display the books in the inventory
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<BookBean> showBooks() throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;

		ArrayList<BookBean> booksInventory=new ArrayList<BookBean>();
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.getBooks);			
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookBean bookBean=new BookBean();
				
				bookBean.setBookId(resultSet.getString("book_id"));
				bookBean.setBookName(resultSet.getString("book_name"));
				bookBean.setAuthor1(resultSet.getString("author1"));
				bookBean.setAuthor2(resultSet.getString("author2"));
				bookBean.setPublisher(resultSet.getString("publisher"));
				bookBean.setYearOfPublication(resultSet.getString("yearofpublication"));
				bookBean.setNoOfCopies(resultSet.getInt("no_of_copies"));
				
				booksInventory.add(bookBean);
			}
			
		}
		catch(SQLException e)
		{
			throw new LibraryException("error in displaying books"+ e.getMessage() );
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return booksInventory;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	removeBook()
	 - Input Parameters	:	bookId
	 - Return Type		:	bookId
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To remove the book from the inventory
	 ********************************************************************************************************/
	
	@Override
	public boolean removeBook(int numCopy,String bookId) throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
	
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet=null;
		boolean status=false;
		int copies=0;
		int count=0;
		
		try
		{
			
			preparedStatement = connection.prepareStatement("SELECT no_of_copies FROM BooksInventory WHERE book_id=?");
			preparedStatement.setString(1,bookId);
			resultSet=preparedStatement.executeQuery();
			//resultSet.next();
			
			if(!resultSet.isBeforeFirst())
			{
				throw new LibraryException("Entered book id doesnot match with any book in the inventory");
			}
			else
			{
				while(resultSet.next())
				{
					copies=resultSet.getInt(1);
				}
				if(copies==numCopy)
				{
					preparedStatement = connection.prepareStatement(IQueryMapper.deleteBook);
					preparedStatement.setString(1,bookId);
					
					count=preparedStatement.executeUpdate();
					
					preparedStatement.close();
					
					if(count==1)
						status=true;
				}
				
				else if(copies>numCopy)
				{
					preparedStatement = connection.prepareStatement(IQueryMapper.updateBookCopies);
					preparedStatement.setInt(1,numCopy);
					preparedStatement.setString(2,bookId);
					
					count=preparedStatement.executeUpdate();
					
					preparedStatement.close();
					
					if(count==1)
						status=true;
				}				
				else
				{
					throw new LibraryException("Entered copies should be less than or equal to available copies");
				}				
			}			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Caught "+sqlException.getMessage());
		}
		
		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}		
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	showRegisteredBooks()
	 - Return Type		:	ArrayList<BookRegistrationBean>
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To show the user registered books
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<BookRegistrationBean> showRegisteredBooks() throws LibraryException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		ArrayList<BookRegistrationBean> bookRegistrations=new ArrayList<BookRegistrationBean>();
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.getBooksRegistered);	
			
			preparedStatement.setString(1,"requested");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookRegistrationBean bookRegistrationBean=new BookRegistrationBean();
				
				bookRegistrationBean.setRegistrationId(resultSet.getString("registration_id"));
				bookRegistrationBean.setBookId(resultSet.getString("book_id"));
				bookRegistrationBean.setUserId(resultSet.getString("user_id"));
				bookRegistrationBean.setRegistrationDate(resultSet.getDate("registrationdate"));
				
				bookRegistrations.add(bookRegistrationBean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Error in showing registered books "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in adding books");
			}
		}
		return bookRegistrations;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	grantBook()
	 - Input Parameters	:	registrationId, bookId
	 - Return Type		:	String
	 - Throws		    :  	LibraryException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	Librarian grant a book requested by the user
	 ********************************************************************************************************/
	
	@Override
	public String grantBook(String registrationId, String bookId) throws LibraryException 
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String transactionId=null;		
		String tRegistrationId=null;
		String tBookId=null;
		String tUserId=null;
		Date tRegistrationDate=null;
		
		int copies=0;
		
		try
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.getNoOfCopies);
			preparedStatement.setString(1,bookId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
				copies=resultSet.getInt(1);
			
			preparedStatement.close();
			
			if(copies>=1)
			{
					preparedStatement = connection.prepareStatement(IQueryMapper.bookIssued);
					preparedStatement.setString(1,registrationId);
					preparedStatement.executeUpdate();
					preparedStatement.close();
		
					preparedStatement=connection.prepareStatement(IQueryMapper.getTransactionId);
					resultSet=preparedStatement.executeQuery();
					while(resultSet.next())
						transactionId=resultSet.getString(1);
					
					preparedStatement=connection.prepareStatement(IQueryMapper.setStatus);
					preparedStatement.setString(1, "issued");
					preparedStatement.setString(2, registrationId);
					preparedStatement.executeUpdate();
					
					preparedStatement=connection.prepareStatement(IQueryMapper.updateCopies);
					preparedStatement.setString(1, bookId);
					preparedStatement.executeUpdate();					
			}
			else
			{
				throw new LibraryException("Requested book is out of copies");
			}
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("Error in granting a book "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in granting a book");
			}
		}
		
		return transactionId;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	isBookAvailable()
	 - Input Parameters	:	bookId
	 - Return Type		:	int
	 - Throws		    :  	StudentException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To check whether the book is available or not
	 ********************************************************************************************************/
	
	@Override
	public int isBookAvailable(String bookId) throws StudentException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		int status=0;
		try
		{
			//System.out.println("Entered book id is : "+bookId);
			preparedStatement = connection.prepareStatement(IQueryMapper.selectCopies);
			preparedStatement.setString(1,bookId);
			resultSet=preparedStatement.executeQuery();
			if(resultSet.next())
			{
				int copies=resultSet.getInt("no_of_copies");
				if(copies>0)
				{
					status=1;
				}
				else
				{
					status=2;
				}
			}
			else
				status=3;
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing db connection");
			}
		}
		return status;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	addRequest()
	 - Input Parameters	:	userId, bookId
	 - Return Type		:	String
	 - Throws		    :  	StudentException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To add a request for a book
	 ********************************************************************************************************/
	
	@Override
	public String addRequest(String userId, String bookId) throws StudentException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String registrationId=null;
		String bookIdTemp=null;
		int count=0;
		String status=null;
		
		try
		{
			preparedStatement = connection.prepareStatement("SELECT COUNT(book_id) FROM BooksRegistration WHERE user_id=? AND status IN ('requested','issued')");
			preparedStatement.setString(1,userId);
			resultSet=preparedStatement.executeQuery();
			
			while(resultSet.next())
			{
				count=resultSet.getInt(1);
			}
			
			if(count>=3)
			{
				throw new StudentException("Student cannot place a request for more than 3 books");
			}
			
			else
			{
				preparedStatement = connection.prepareStatement(IQueryMapper.selectBookId);
				preparedStatement.setString(1,userId);
				resultSet=preparedStatement.executeQuery();
				
				while(resultSet.next())
				{
					bookIdTemp=resultSet.getString(1);
					if(bookId.equals(bookIdTemp))
					{
						preparedStatement = connection.prepareStatement(IQueryMapper.selectStatus);
						preparedStatement.setString(1,userId);
						resultSet=preparedStatement.executeQuery();
						resultSet.next();
						status=resultSet.getString(1);
						System.out.println(status);
						if(status.equals("issued"))
						{
							throw new StudentException("Book is already granted");
						}
						else if(status.equals("requested"))
						{
							throw new StudentException("Request for the book cannot be placed more than 1 time");
						}					
					}			
				}
				preparedStatement.close();
				
				preparedStatement = connection.prepareStatement(IQueryMapper.insertBookRegistration);
				preparedStatement.setString(1,bookId);
				preparedStatement.setString(2,userId);
				preparedStatement.setString(3, "requested");
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement(IQueryMapper.selectRegistrationId);
				ResultSet rs=preparedStatement.executeQuery();
				rs.next();
				registrationId=rs.getString(1);
				preparedStatement.close();
			}
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing db connection");
			}
		}
		return registrationId;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	showUserBooks()
	 - Input Parameters	:	userId
	 - Return Type		:	ArrayList<BookRegistrationBean>
	 - Throws		    :  	StudentException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To display the books that are granted for a single user
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<BookRegistrationBean> showUserBooks(String userid) throws StudentException
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		ArrayList<BookRegistrationBean> bookRegistrations=new ArrayList<BookRegistrationBean>();
		try
		{
			preparedStatement = connection.prepareStatement(IQueryMapper.selectBookRegistration);
			
			preparedStatement.setString(1, userid);
			preparedStatement.setString(2,"issued");
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				BookRegistrationBean bookRegistrationBean=new BookRegistrationBean();
				
				bookRegistrationBean.setRegistrationId(resultSet.getString("registration_id"));
				bookRegistrationBean.setBookId(resultSet.getString("book_id"));
				bookRegistrationBean.setRegistrationDate(resultSet.getDate("registrationdate"));
				
				bookRegistrations.add(bookRegistrationBean);
			}
			
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing database connection in adding books");
			}
		}
		return bookRegistrations;
	}
	
	/*******************************************************************************************************
	 - Function Name	:	returnBook()
	 - Input Parameters	:	registrationId, bookId
	 - Return Type		:	int
	 - Throws		    :  	StudentException
	 - Author	     	:	TEAM-4
	 - Creation Date	:	07/07/2018
	 - Description		:	To return a book
	 ********************************************************************************************************/
	
	@Override
	public int returnBook(String registrationId, String bookId) throws StudentException 
	{
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		String bookIdTemp=null;
		
		int fine=0;
		try
		{
			preparedStatement=connection.prepareStatement(IQueryMapper.returnedBookId);
			preparedStatement.setString(1, registrationId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())	
			{
				bookIdTemp=resultSet.getString(1);
				
			}
			/*System.out.println("...."+bookId);
			System.out.println("..."+bookIdTemp);
			System.out.println(bookIdTemp==(bookId));
			System.out.println(bookIdTemp.equals(null));*/
			if(bookIdTemp==null)
			{
				throw new StudentException("You entered incorrect registration id");
			}
			else if(!bookIdTemp.equals(bookId))
			{
				throw new StudentException("You entered incorrect book  id");
			}
			preparedStatement=connection.prepareStatement(IQueryMapper.getFine);
			preparedStatement.setString(1, registrationId);
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())	
			{
				fine=resultSet.getInt(1);
			}
			preparedStatement.close();
			
			if(fine!=-1)
			{
				throw new StudentException("the book is already returned");
			}
			else
			{
				fine=0;
				preparedStatement=connection.prepareStatement(IQueryMapper.setReturnDate);
				preparedStatement.setString(1, registrationId);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement(IQueryMapper.setCopies);
				preparedStatement.setString(1, bookId);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement(IQueryMapper.setReturnStatus);
				preparedStatement.setString(1, "returned");
				preparedStatement.setString(2, registrationId);
				preparedStatement.executeUpdate();
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement(IQueryMapper.getDates);
				preparedStatement.setString(1, registrationId);
				resultSet=preparedStatement.executeQuery();
				while(resultSet.next())
				{
					Date issueDate=resultSet.getDate(1);
					Date returnDate=resultSet.getDate(2);
					int days=(int) ((issueDate.getTime()-returnDate.getTime())/(1000*60*60*24));
					
					if(days>30)
						fine=(days-30)*2;
				}
				preparedStatement.close();
				
				preparedStatement=connection.prepareStatement(IQueryMapper.updateFine);
				preparedStatement.setInt(1, fine);
				preparedStatement.setString(2,registrationId);
				preparedStatement.executeUpdate();
			}
		}
		catch(SQLException sqlException)
		{
			throw new StudentException("Caught "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new StudentException("Error in closing database connection in registration phase");
			}
		}
		return fine;
	}

	@Override
	public int generateBookIdSeq() throws LibraryException
	{
		int bookSeq=0;
		
		Connection connection=DBConnection.getConnection();
		
		PreparedStatement preparedStatement=null;
		ResultSet resultSet=null;
		
		try
		{
			preparedStatement = connection.prepareStatement("select book_id_seq.nextval from dual");
			
			resultSet=preparedStatement.executeQuery();
			while(resultSet.next())
			{
				bookSeq=resultSet.getInt(1);
			}		
		}
		catch(SQLException sqlException)
		{
			throw new LibraryException("error incurred while generating sequence id of a book "+sqlException.getMessage());
		}

		finally
		{
			try 
			{
				preparedStatement.close();
				connection.close();
				resultSet.close();
			}
			catch (SQLException sqlException) 
			{
				throw new LibraryException("Error in closing database connection in generating a sequence for bookid");
			}
		}
		return bookSeq;
	}

}
